package com.example.demo.error;

public class CourseNotFoundException extends Exception {
	public CourseNotFoundException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}
}
