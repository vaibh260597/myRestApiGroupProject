package com.example.demo.error;

public class StudentNotFoundException extends Exception{

	public StudentNotFoundException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
